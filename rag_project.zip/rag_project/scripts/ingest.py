from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct, VectorParams, Distance
from sentence_transformers import SentenceTransformer

COLLECTION_NAME = "documents"

client = QdrantClient(host="localhost", port=6333)
model = SentenceTransformer("all-MiniLM-L6-v2")

if not client.collection_exists(COLLECTION_NAME):
    client.create_collection(
        collection_name=COLLECTION_NAME,
        vectors_config=VectorParams(size=384, distance=Distance.COSINE)
    )

file_path = "../data/exemple.txt"

with open(file_path, "r", encoding="utf-8") as f:
    text = f.read()

def split_text(text, max_length=400):
    paragraphs = text.split("\n\n")  # découpe logique
    chunks = []
    current_chunk = ""

    for para in paragraphs:
        if len(current_chunk) + len(para) <= max_length:
            current_chunk += para + " "
        else:
            chunks.append(current_chunk.strip())
            current_chunk = para + " "

    if current_chunk:
        chunks.append(current_chunk.strip())

    return chunks


# ✅ ICI C'ÉTAIT LE PROBLÈME
chunks = split_text(text)

points = []
for i, chunk in enumerate(chunks):
    vector = model.encode(chunk).tolist()
    points.append(
        PointStruct(
            id=i,
            vector=vector,
            payload={"text": chunk}
        )
    )

client.upsert(
    collection_name=COLLECTION_NAME,
    points=points
)

print("✅ Ingestion terminée avec succès")
