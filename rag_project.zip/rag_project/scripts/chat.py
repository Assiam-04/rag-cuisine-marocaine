from qdrant_client import QdrantClient
from sentence_transformers import SentenceTransformer
import requests

# 1. Connexion à Qdrant (chez Imane)
client = QdrantClient(
    host="localhost",
    port=6333
)



# 2. Modèle d'embedding
model = SentenceTransformer("all-MiniLM-L6-v2")

# 3. Question utilisateur
question = input("Pose ta question : ")

# 4. Vectoriser la question
query_vector = model.encode(question).tolist()

# 5. Recherche dans Qdrant (API récente)
results = client.query_points(
    collection_name="documents",
    query=query_vector,
    limit=3
)

# 6. Construire le contexte
context = "\n".join([point.payload["text"] for point in results.points])

# 7. Prompt pour Ollama
prompt = f"""
Tu es un assistant expert en cuisine marocaine.
Utilise uniquement le contexte suivant pour répondre.

CONTEXTE:
{context}

QUESTION:
{question}
"""

# 8. Appel à Ollama
response = requests.post(
    "http://localhost:11434/api/generate",
    json={
        "model": "mistral",
        "prompt": prompt,
        "stream": False
    }
)

print("\n🤖 Réponse du chatbot :\n")
print(response.json()["response"])
