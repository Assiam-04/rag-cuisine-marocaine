\# RAG Project (Qdrant + Python)



\## Description

Projet simple de Retrieval-Augmented Generation avec :

\- Qdrant

\- Sentence Transformers

\- Python



\## Structure

\- data/ : documents texte

\- qdrant/ : configuration Docker

\- scripts/ : scripts Python



\## Lancer Qdrant

```bash

docker compose up -d



