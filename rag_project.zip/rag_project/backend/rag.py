def ask_question(question: str):
    return f"Question reçue : {question}"
