import streamlit as st
from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient

# ---- Config ----
COLLECTION_NAME = "documents"
TOP_K = 2
SCORE_THRESHOLD = 0.45 # 🔴 TRÈS IMPORTANT

# ---- Page config ----
st.set_page_config(
    page_title="Mini RAG Project",
    page_icon="📚",
    layout="centered"
)

# ---- Header ----
st.markdown("""
# 📚 Mini RAG Project
Pose une question et découvre les passages **les plus pertinents** issus de tes documents.
""")

st.divider()

# ---- Init models ----
@st.cache_resource
def load_model():
    return SentenceTransformer("all-MiniLM-L6-v2")

@st.cache_resource
def load_client():
    return QdrantClient(url="http://localhost:6333")

model = load_model()
client = load_client()

# ---- Sidebar ----
with st.sidebar:
    st.header("⚙️ Paramètres")
    st.markdown(f"""
    - **Collection** : `{COLLECTION_NAME}`
    - **Top K** : {TOP_K}
    - **Score min** : {SCORE_THRESHOLD}
    """)
    st.info("Les résultats avec un score faible sont automatiquement filtrés.")

# ---- UI ----
question = st.text_input(
    "💬 Pose ta question",
    placeholder="Ex : Quels sont les ingrédients du tajine ?"
)

if question:
    with st.spinner("🔎 Recherche des passages pertinents..."):
        query_vector = model.encode(question).tolist()

        results = client.query_points(
            collection_name=COLLECTION_NAME,
            query=query_vector,
            limit=TOP_K,
            score_threshold=SCORE_THRESHOLD
        )

    st.subheader("📌 Résultats")

    if not results.points:
        st.warning("❌ Aucun résultat pertinent trouvé.")
    else:
        for i, point in enumerate(results.points, start=1):
            st.markdown(
                f"""
                ### 🧠 Résultat {i}
                **Score de similarité :** `{point.score:.3f}`
                """
            )

            st.success(point.payload.get("text", ""))
            st.divider()

# ---- Footer ----
st.markdown(
    "<div style='text-align:center; color:gray;'>Mini RAG Project • Streamlit + Qdrant</div>",
    unsafe_allow_html=True
)
